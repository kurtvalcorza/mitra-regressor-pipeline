"""Review probes for tutorials/DIMER_FreshRetailNet_MultiModel_Regression_Workshop.ipynb (v1, revision 3.1.0).

Reviewed commit a9a6f056ebd52434cdcfd2b42b29bd9b83add453, notebook blob 6508437e79c4db737d19dfa752de06d7e55cdbef.

Evidence basis: DIRECT EXECUTION on a local Windows CPU (Python 3.12, no GPU), NOT Colab.
Stand-ins, stated explicitly:
  * all foundation-model conditions are switched off (RUN_*_ICL/FINETUNED=False), so no uv environments,
    no checkpoints and no foundation-model runner are exercised; the classical, freeze, test, bootstrap,
    inference-preview and export cells run unmodified;
  * cell 0.3's hard-coded "/content" root is rewritten to a per-journey scratch folder;
  * form values are overridden by rewriting their `# @param` lines in memory (EXE6 style), failing if a field is absent;
  * IPython display() is captured; matplotlib uses the Agg backend.
Section 1.1 downloads the pinned sample from raw.githubusercontent.com for real.

Usage: python run_probes.py            (runs every probe, writes results.json)
       python run_probes.py --journey X (internal: one journey in a fresh interpreter)
"""
from __future__ import annotations

import io
import json
import re
import subprocess
import sys
import traceback
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
NOTEBOOK = HERE / "tutorials" / "DIMER_FreshRetailNet_MultiModel_Regression_Workshop.ipynb"
SAMPLE_ZIP = HERE / "pinned_freshretailnet-h7.zip"  # git show 78e12407:examples/sample-data/freshretailnet-h7.zip
WORK = HERE / "probe_work"

CELL_TITLES = ["0.1", "0.2", "0.3", "1.1", "1.2", "2.1", "2.2", "3.1", "3.2", "3.3", "3.4", "3.5", "3.6", "4.1",
               "4.2", "4.3", "4.4", "5.1", "5.2", "5.3", "5.4", "5.5", "5.6", "6.1", "6.2", "7.1", "8.0", "8.1",
               "8.2", "8.3", "8.4", "10.1", "summary"]
NO_FM = {"RUN_MITRA_ICL": False, "RUN_TABDPT_ICL": False, "RUN_TABPFN3_ICL": False, "RUN_TABICLV2_ICL": False}


def code_cells() -> list[str]:
    nb = json.loads(NOTEBOOK.read_text(encoding="utf-8"))
    cells = ["".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code"]
    assert len(cells) == len(CELL_TITLES), len(cells)
    for title, src in zip(CELL_TITLES, cells):
        if title[0].isdigit():
            assert f"@title {title} " in src, (title, src[:80])
    return cells


def set_params(src: str, overrides: dict) -> str:
    for name, value in overrides.items():
        pattern = re.compile(rf"^(\s*){re.escape(name)}\s*=\s*[^#\n]*(#\s*@param.*)$", re.M)
        if not pattern.search(src):
            raise KeyError(f"form field {name} not found")
        src = pattern.sub(lambda m: f"{m.group(1)}{name} = {value!r} {m.group(2)}", src, count=1)
    return src


class Runner:
    def __init__(self, root: Path):
        import matplotlib
        matplotlib.use("Agg")
        import IPython.display
        self.displayed: list = []
        IPython.display.display = lambda *a, **k: self.displayed.extend(a)
        self.cells = code_cells()
        self.root = root
        self.ns: dict = {"__name__": "__main__"}
        self.log: list[dict] = []

    def run(self, title: str, overrides: dict | None = None) -> dict:
        src = self.cells[CELL_TITLES.index(title)]
        if title == "0.3":
            src = src.replace('"/content', '"' + self.root.as_posix() + "/content")
        if overrides:
            src = set_params(src, overrides)
        out = io.StringIO()
        old = sys.stdout
        sys.stdout = out
        try:
            exec(compile(src, f"<cell {title}>", "exec"), self.ns)
            entry = {"cell": title, "ok": True}
        except BaseException as exc:  # noqa: BLE001 - we record every failure
            entry = {"cell": title, "ok": False, "error_type": type(exc).__name__, "error": str(exc)[:500]}
        finally:
            sys.stdout = old
        entry["stdout_tail"] = out.getvalue()[-600:]
        self.log.append(entry)
        return entry

    def run_all(self, overrides: dict, stop_on_error: bool = True) -> dict | None:
        """Colab 'Run all' semantics: stop at the first failing cell."""
        for title in CELL_TITLES:
            entry = self.run(title, {k: v for k, v in overrides.items() if self._has(title, k)})
            if not entry["ok"] and stop_on_error:
                return entry
        return None

    def _has(self, title: str, name: str) -> bool:
        src = self.cells[CELL_TITLES.index(title)]
        return re.search(rf"^\s*{re.escape(name)}\s*=.*#\s*@param", src, re.M) is not None


def table(df, cols=None, n=20):
    import pandas as pd
    if df is None:
        return None
    if isinstance(df, pd.DataFrame):
        d = df[cols] if cols else df
        return json.loads(d.head(n).round(6).to_json(orient="records"))
    return str(df)


# --------------------------------------------------------------------------------------- journeys

def journey_default_classical(root: Path) -> dict:
    """Clean default Run all, foundation models off (CPU stand-in). Then the post-run active-learning trap."""
    r = Runner(root)
    first_error = r.run_all(dict(NO_FM))
    ns = r.ns
    res = {"first_error": first_error, "cells_ok": sum(e["ok"] for e in r.log), "cells_run": len(r.log)}
    if first_error is None:
        import numpy as np
        b = ns["BOOTSTRAP_RESULTS"]
        ref = b[b.is_reference].iloc[0]
        observed_minus = {row.model_key: float(ref["mae"] - row.mae) for row in b.itertuples() if not row.is_reference}
        reported = {row.model_key: float(row.gain_vs_reference) for row in b.itertuples() if not row.is_reference}
        res.update(
            dataset_provenance={k: str(v) for k, v in ns["DATASET_PROVENANCE"].items()},
            baseline_validation=table(ns["baseline_validation_results"], ["model_key", "mae", "rmse", "r2"]),
            frozen_keys=list(json.loads((ns["SESSION"].root / "freeze.json").read_text())["selected"]),
            final_test=table(ns["final_test_results"], ["model_key", "mae", "rmse", "r2"]),
            bootstrap_reference=str(ref["model_key"]),
            gain_reported_bootstrap_mean=reported,
            gain_observed_point_difference=observed_minus,
            gain_max_abs_discrepancy=max(abs(reported[k] - observed_minus[k]) for k in reported),
            inference_model=str(ns["model_key"]),
            export_files=sorted(p.relative_to(ns["export_directory"]).as_posix()
                                for p in Path(ns["export_directory"]).rglob("*") if p.is_file()),
            figure_titles=sorted(v["title"] for v in ns["FIGURE_REGISTRY"].values()),
            summary_stdout=r.log[-1]["stdout_tail"],
            workspace_root=str(ns["WORKSPACE_ROOT"]),
        )
        # Active learning after the default Run all: change one baseline control, as the forms invite.
        a1 = r.run("4.2", {"RF_TREES": 100})
        # Documented recovery: turn on Start new experiment in 0.3, then rerun the changed cell.
        a2 = r.run("0.3", {"START_NEW_EXPERIMENT": True})
        a3 = r.run("4.2", {"RF_TREES": 100})
        session_root_after_new = str(ns["SESSION_ROOT"])
        session_obj_root = str(ns["SESSION"].root)
        # Undocumented recovery: also rerun 1.1, 1.2 and 2.1 (0.3 is switched back off first, as its note asks).
        a4 = [r.run("0.3", {"START_NEW_EXPERIMENT": False})] + [r.run(t) for t in ("1.1", "1.2", "2.1")]
        a5 = r.run("4.2", {"RF_TREES": 100})
        res["post_run_active_learning"] = {
            "change_rf_trees_after_freeze": a1, "start_new_experiment_0_3": a2,
            "rerun_4_2_after_new_experiment": a3,
            "SESSION_ROOT_after_0_3": session_root_after_new, "SESSION_object_root_after_0_3": session_obj_root,
            "rerun_1_1_to_2_1": a4, "rerun_4_2_after_1_1_to_2_1": a5,
        }
    res["log"] = [{k: v for k, v in e.items() if k != "stdout_tail"} for e in r.log]
    return res


def journey_explore_before_freeze(root: Path) -> dict:
    """Follow the 8.0 prose: leave Freeze now off while exploring; change one control; then freeze and test."""
    r = Runner(root)
    first_error = r.run_all({**NO_FM, "FREEZE_NOW": False})
    res = {"run_all_with_freeze_off_first_error": first_error}
    ns = r.ns
    rf_before = float(ns["baseline_validation_results"].set_index("model_key").loc["random_forest", "mae"])
    r.run("4.2", {"RF_TREES": 100})
    rf_after = float(ns["baseline_validation_results"].set_index("model_key").loc["random_forest", "mae"])
    for t in ("4.3", "4.4", "5.4", "5.5", "5.6", "6.1", "6.2", "7.1"):
        r.run(t, dict(NO_FM) if t == "5.1" else None)
    e80 = r.run("8.0", {"FREEZE_NOW": True})
    later = [r.run(t) for t in ("8.1", "8.2", "8.3", "8.4", "10.1", "summary")]
    frozen = json.loads((ns["SESSION"].root / "freeze.json").read_text())
    rf_controls = frozen["controls"]["random_forest"]["parameters"]
    test = ns["final_test_results"].set_index("model_key")
    res.update(rf_validation_mae_300=rf_before, rf_validation_mae_100=rf_after,
               freeze=e80, later=later, frozen_rf_parameters=rf_controls,
               test_random_forest_mae=float(test.loc["random_forest", "mae"]),
               stale_registered_runs=len(list((ns["SESSION"].root / "runs").glob("random_forest-*"))))
    res["log"] = [{k: v for k, v in e.items() if k != "stdout_tail"} for e in r.log]
    return res


def journey_metric_r2(root: Path) -> dict:
    r = Runner(root)
    first_error = r.run_all({**NO_FM, "PRIMARY_METRIC": "r2"})
    ns = r.ns
    res = {"first_error": first_error}
    if first_error is None:
        res["bootstrap"] = table(ns["BOOTSTRAP_RESULTS"], ["model_key", "r2", "ci_low", "ci_high", "gain_vs_reference"])
        res["validation_plot_metric_is_mae_even_when_primary_is_r2"] = "combined_validation_results.mae" in r.cells[CELL_TITLES.index("5.6")]
    return res


def _write_byod(path: Path, *, drop: str | None = None, nested: bool = True) -> Path:
    with zipfile.ZipFile(SAMPLE_ZIP) as src, zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as dst:
        for info in src.infolist():
            name = Path(info.filename).name
            if name not in {"train.csv", "val.csv", "test.csv"}:
                continue
            data = src.read(info)
            if drop:
                import pandas as pd
                df = pd.read_csv(io.BytesIO(data)).drop(columns=[drop])
                data = df.to_csv(index=False).encode()
            dst.writestr(("my_data/" if nested else "") + name, data)
    return path


def journey_byod_positive(root: Path) -> dict:
    root.mkdir(parents=True, exist_ok=True)
    z = _write_byod(root / "byod_positive.zip")
    r = Runner(root)
    first_error = r.run_all({**NO_FM, "USE_BYOD": True, "BYOD_ZIP_PATH": str(z)})
    ns = r.ns
    res = {"first_error": first_error, "cells_ok": sum(e["ok"] for e in r.log)}
    if first_error is None:
        res["acquisition"] = ns["DATASET_PROVENANCE"]["acquisition_method"]
        res["sha_verified"] = ns["DATASET_PROVENANCE"]["sha256_verified_against_published_value"]
        res["test_models"] = len(ns["final_test_results"])
        res["summary_stdout"] = r.log[-1]["stdout_tail"]
    return res


def _byod_negative(root: Path, case: str) -> dict:
    """One rejected BYOD input per fresh interpreter (the 0.3 helper guard is per process)."""
    root.mkdir(parents=True, exist_ok=True)
    if case == "missing_lag_1":
        path = _write_byod(root / "byod_missing_lag1.zip", drop="lag_1")
    elif case == "not_a_zip":
        path = root / "not_a_zip.csv"
        path.write_text("a,b\n1,2\n")
    else:
        path = root / "does_not_exist.zip"
    r = Runner(root)
    return {"case": case, "first_error": r.run_all({**NO_FM, "USE_BYOD": True, "BYOD_ZIP_PATH": str(path)}),
            "models_fitted_before_error": "fitted_models" in r.ns}


JOURNEYS = {
    "default_classical": journey_default_classical,
    "explore_before_freeze": journey_explore_before_freeze,
    "metric_r2": journey_metric_r2,
    "byod_positive": journey_byod_positive,
    "byod_negative_missing_lag_1": lambda root: _byod_negative(root, "missing_lag_1"),
    "byod_negative_not_a_zip": lambda root: _byod_negative(root, "not_a_zip"),
    "byod_negative_missing_path": lambda root: _byod_negative(root, "missing_path"),
}

# --------------------------------------------------------------------------------------- cell-level probes


def cell_83_probe(test_truth, preds: dict, classical_val: dict, metric: str, seed=0, n=1000) -> dict:
    """Execute the notebook's own 8.3 source with a crafted namespace (no model runs)."""
    import numpy as np
    import pandas as pd
    src = code_cells()[CELL_TITLES.index("8.3")]
    src = set_params(src, {"BOOTSTRAP_RESAMPLES": n}).replace("show_and_save_plot(", "(lambda **k: None)(")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    rows = len(test_truth)
    frames = {"test": pd.DataFrame({"target": np.asarray(test_truth, float)})}
    ftp = {k: pd.DataFrame({"row_id": range(rows), "target": test_truth, "prediction": v}) for k, v in preds.items()}

    def sc(truth, pred):
        e = truth - pred
        if metric == "mae":
            return float(np.mean(np.abs(e)))
        if metric == "rmse":
            return float(np.sqrt(np.mean(e ** 2)))
        return float(1 - np.sum(e ** 2) / np.sum((truth - truth.mean()) ** 2))

    t = np.asarray(test_truth, float)
    final = pd.DataFrame([{"model_key": k, "model": k, "condition": "c", "run_id": "r-" + k, metric: sc(t, np.asarray(v, float))}
                          for k, v in preds.items()])
    ns = {"np": np, "pd": pd, "plt": plt, "display": lambda *a, **k: None, "frames": frames, "TARGET_COLUMN": "target",
          "final_test_results": final, "foundation_test_predictions": ftp, "PRIMARY_METRIC": metric, "RANDOM_SEED": seed,
          "baseline_validation_results": pd.DataFrame([{"model_key": k, metric: v} for k, v in classical_val.items()])}
    old = sys.stdout
    sys.stdout = io.StringIO()
    try:
        exec(compile(src, "<cell 8.3>", "exec"), ns)
        res = {"ok": True}
        b = ns["BOOTSTRAP_RESULTS"]
        res["ci_low"] = [None if v != v else float(v) for v in b["ci_low"]]
        res["nonfinite_draws"] = {k: int((~np.isfinite(v)).sum()) for k, v in ns["scores"].items()}
    except BaseException as exc:  # noqa: BLE001
        res = {"ok": False, "error_type": type(exc).__name__, "error": str(exc)[:300]}
    finally:
        sys.stdout = old
    return res


def data_facts() -> dict:
    import numpy as np
    import pandas as pd
    with zipfile.ZipFile(SAMPLE_ZIP) as z:
        names = {Path(i.filename).name: i for i in z.infolist() if not i.is_dir()}
        frames = {s: pd.read_csv(io.BytesIO(z.read(names[f"{s}.csv"]))) for s in ("train", "val", "test")}
    allt = pd.concat([f.target for f in frames.values()])
    val = frames["val"]
    bands = pd.qcut(val.stockout_hours, q=4, duplicates="drop")
    return {
        "members": sorted(names),
        "rows": {s: len(f) for s, f in frames.items()},
        "columns": list(frames["train"].columns),
        "zero_target_rate_all_percent": round(100 * float(allt.eq(0).mean()), 3),
        "zero_target_rate_by_split_percent": {s: round(100 * float(f.target.eq(0).mean()), 3) for s, f in frames.items()},
        "target_max": float(allt.max()), "target_median": float(allt.median()),
        "months_by_split": {s: sorted(int(m) for m in f.month.unique()) for s, f in frames.items()},
        "val_stockout_hours_zero_share": round(float(val.stockout_hours.eq(0).mean()), 4),
        "val_stockout_hours_quartile_bands": [str(b) for b in bands.cat.categories],
        "val_stockout_hours_unique": int(val.stockout_hours.nunique()),
    }


def static_checks() -> dict:
    nb = json.loads(NOTEBOOK.read_text(encoding="utf-8"))
    md = "\n".join("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "markdown")
    code = code_cells()
    c80 = code[CELL_TITLES.index("8.0")]
    return {
        "nbformat": [nb["nbformat"], nb["nbformat_minor"]],
        "code_cells": len(code), "markdown_cells": sum(c["cell_type"] == "markdown" for c in nb["cells"]),
        "saved_outputs": sum(len(c.get("outputs", [])) for c in nb["cells"] if c["cell_type"] == "code"),
        "metadata_dimer": nb["metadata"].get("dimer"), "workshop_revision": nb["metadata"].get("workshop_revision"),
        "freeze_now_default": re.search(r"^FREEZE_NOW = (\w+)", c80, re.M).group(1),
        "evaluate_frozen_test_default": re.search(r"^EVALUATE_FROZEN_TEST = (\w+)", code[CELL_TITLES.index("8.1")], re.M).group(1),
        "prose_leave_freeze_off": "Leave **Freeze now** off while exploring" in md,
        "finetune_defaults": re.findall(r"^(RUN_\w+_FINETUNED) = (\w+)", code[CELL_TITLES.index("5.1")], re.M),
        "research_question_finetuning": "Does task-specific fine-tuning improve performance" in md,
        "hard_coded_zero_rate_text": "Approximately 3.4% of target observations are zero-valued" in md,
        "conclusion_mae_only": "obtained an MAE of" in md and "PRIMARY_METRIC" not in md,
        "conclusion_ablation_partitions": re.findall(r"did not materially change\]\*\* (\w+) MAE", md),
        "workspace_v2_naming": [s for s in ("dimer_tabular_workshop_v2", "dimer-freshretailnet-workshop-v2",
                                            "classical-workshop-v2") if any(s in c for c in code) or s in md],
        "expected_result_mentions_local_archive_path": "the local archive path" in md,
        "provenance_has_local_path_key": "\"archive_path\"" in code[CELL_TITLES.index("1.1")],
        "estimated_time_text": re.search(r"\*\*Estimated time:\*\*([^\n]*)", md).group(1).strip(),
        "title": md.splitlines()[0],
        "has_troubleshooting": "troubleshoot" in md.lower(),
        "has_sample_answers": "sample answer" in md.lower() or "<details" in md.lower(),
        "has_input_model_output": "Input → Model" in md or "Input -> Model" in md,
        "regression_metrics_redefined_in_4_1": "def regression_metrics" in code[CELL_TITLES.index("4.1")],
        "make_result_record_used_elsewhere": sum("make_result_record(" in c for c in code) > 1,
        "compile_all_code_cells": all(compile(c, "x", "exec") is not None for c in code),
    }


def main() -> None:
    if len(sys.argv) == 3 and sys.argv[1] == "--journey":
        name = sys.argv[2]
        root = WORK / name
        result = JOURNEYS[name](root)
        (WORK / f"{name}.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
        return
    WORK.mkdir(exist_ok=True)
    results = {"basis": "direct execution, local Windows CPU, Python %s; foundation models off; not Colab" % sys.version.split()[0],
               "static": static_checks(), "data_facts": data_facts()}
    rng = __import__("numpy").random.default_rng(1)
    t = rng.gamma(2.0, 0.5, 200)
    results["cell_8_3_foundation_only"] = cell_83_probe(t, {"tabiclv2_icl": t + 0.1, "mitra_icl": t - 0.1},
                                                        {"lightgbm": 0.3, "random_forest": 0.31}, "mae")
    results["cell_8_3_with_lightgbm"] = cell_83_probe(t, {"tabiclv2_icl": t + 0.1, "lightgbm": t - 0.2},
                                                      {"lightgbm": 0.3, "random_forest": 0.31}, "mae")
    results["cell_8_3_r2_two_rows"] = cell_83_probe([0.0, 1.0], {"lightgbm": [0.1, 0.9], "tabiclv2_icl": [0.2, 0.7]},
                                                    {"lightgbm": 0.9}, "r2")
    for name in JOURNEYS:
        proc = subprocess.run([sys.executable, __file__, "--journey", name], capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=3000)
        path = WORK / f"{name}.json"
        results[f"journey_{name}"] = (json.loads(path.read_text(encoding="utf-8")) if path.exists()
                                      else {"crashed": True, "stderr": proc.stderr[-2000:]})
    (HERE / "results.json").write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")
    print("wrote", HERE / "results.json")


if __name__ == "__main__":
    main()
