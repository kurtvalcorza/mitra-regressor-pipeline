"""Review probes for tutorials/mitra_regressor_predictor_inference_colab.ipynb (row 50, prefix MRP).

Direct CPU execution of the notebook's own code cells, in order, in one namespace per probe, each probe in a fresh
Python process. Install cell 3 is skipped (DIMER_NOTEBOOK_CI_PREINSTALLED=1) inside the repository's read-only .venv,
which already holds the notebook's exact pins (autogluon.tabular 1.5.0, lightgbm 4.6.0, huggingface-hub 0.36.2;
torch CPU; Python 3.12.12). The digest-verified Mitra snapshot is pre-copied into each work directory, so
stage_missing_files fetches nothing (the Hub download is NOT exercised). Form values are changed only by rewriting
the cell's own `NAME = value  # @param` line. google.colab.files.upload is stubbed (in-memory payloads) only where
stated; `default_jupyter` runs with NO stub, as a plain Jupyter kernel would.

The external bundle is produced by a SEPARATE process running the companion E2E notebook
(tutorials/mitra_regressor_colab.ipynb, same revision) with one labelled host deviation in that producer only:
MAX_MEMORY_USAGE_RATIO=3.0 (this host had ~3.5-7 GB free RAM). The reviewed notebook runs with no override.
New input = that run's independent test partition with the target column removed.

Usage: python run_probes.py REPO WORKROOT RESULTS MODE
MODE in {bundle, default_jupyter, default_upload_no_digest, paths, mixed, recovery, bundle_alone, static}
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import time
import types
import warnings
import zipfile
from pathlib import Path

REPO, ROOT, RESULTS, MODE = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), sys.argv[4]
NB = REPO / 'tutorials' / 'mitra_regressor_predictor_inference_colab.ipynb'
E2E = REPO / 'tutorials' / 'mitra_regressor_colab.ipynb'
UPLOAD: dict[str, bytes] = {}
HOST_MEMORY_RATIO = 3.0
OUTP = 'mitra_regressor_predictor_inference'


def cells(path):
    return [''.join(c['source']) for c in json.loads(path.read_text(encoding='utf-8'))['cells']]


def save(key, value):
    data = json.loads(RESULTS.read_text(encoding='utf-8')) if RESULTS.exists() else {}
    data[key] = value
    RESULTS.write_text(json.dumps(data, indent=2, default=str), encoding='utf-8')


def set_param(src, name, value):
    pat = re.compile(rf'^{name} = .*?(  # @param.*)?$', re.M)
    assert pat.search(src), name
    return pat.sub(lambda m: f'{name} = {value!r}' + (m.group(1) or ''), src, count=1)


def run(ns, src_cells, idx, params=None, label=None):
    src = src_cells[idx]
    for k, v in (params or {}).items():
        src = set_param(src, k, v)
    out = io.StringIO()
    t0 = time.time()
    err = None
    with warnings.catch_warnings(record=True) as caught, contextlib.redirect_stdout(out), contextlib.redirect_stderr(out):
        warnings.simplefilter('always')
        try:
            exec(compile(src, f'cell{idx}', 'exec'), ns)
        except BaseException as exc:  # noqa: BLE001
            err = f'{type(exc).__name__}: {exc}'
    rec = {'cell': idx, 'label': label, 'params': {k: (v if 'SHA' not in k else str(v)[:12] + '...') for k, v in (params or {}).items()},
           'seconds': round(time.time() - t0, 1), 'error': err, 'stdout_tail': out.getvalue()[-2000:],
           'warnings': sorted({f'{w.category.__name__}: {str(w.message)[:160]}' for w in caught})[:10]}
    print(f'cell {idx} {label or ""} {rec["seconds"]}s err={err}', file=sys.__stdout__, flush=True)
    return rec


def stub_colab():
    colab = types.ModuleType('google.colab')
    colab.files = types.SimpleNamespace(upload=lambda: dict(UPLOAD))
    google = types.ModuleType('google')
    google.colab = colab
    sys.modules['google'] = google
    sys.modules['google.colab'] = colab


def fresh_inf_dir():
    work = ROOT / 'inf'
    for d in ('outputs', 'external-artifact'):
        shutil.rmtree(work / d, ignore_errors=True)
    os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
    os.chdir(work)
    return work


def bundle_info():
    info = json.loads((ROOT / 'bundle.json').read_text(encoding='utf-8'))
    return Path(info['zip']), info['sha256'], Path(info['new_csv'])



def bundle():
    """Produce the external bundle in a separate process from the companion E2E notebook; also measure whether the
    rows the release workflow scores (load_diabetes().data.tail(24)) are disjoint from the bundle's support rows."""
    work = ROOT / 'e2e'
    os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
    os.chdir(work)
    stub_colab()
    src = cells(E2E)
    ns = {'__name__': '__main__'}
    recs = []
    for i in (3, 5, 7, 9, 11, 13, 15, 17, 19):
        recs.append(run(ns, src, i, {'MAX_MEMORY_USAGE_RATIO': HOST_MEMORY_RATIO} if i == 13 else None, label='e2e'))
    zp = work / 'outputs' / 'mitra_regressor_predictor.zip'
    sha = hashlib.sha256(zp.read_bytes()).hexdigest()
    target = ns['TARGET_COLUMN']
    new = ns['test_data'].drop(columns=[target])
    new_csv = ROOT / 'new_rows.csv'
    new.to_csv(new_csv, index=False)
    ns['test_data'].to_csv(ROOT / 'new_rows_labelled.csv', index=False)
    ext = ROOT / 'external'
    ext.mkdir(exist_ok=True)
    shutil.copy2(zp, ext / zp.name)
    (ROOT / 'bundle.json').write_text(json.dumps({'zip': str(ext / zp.name), 'sha256': sha, 'new_csv': str(new_csv)}), encoding='utf-8')
    with zipfile.ZipFile(zp) as zf:
        names = [(i.filename, i.file_size) for i in zf.infolist()]
    # CI-workflow input rows vs the support (train) partition used for the bundle
    from sklearn.datasets import load_diabetes
    feats = [c for c in ns['train_data'].columns if c != target]
    ci_rows = load_diabetes(as_frame=True).data.tail(24)
    key = lambda df: {tuple(round(float(v), 10) for v in r) for r in df[feats].to_numpy()}
    support, val, test = key(ns['train_data']), key(ns['holdout_data']), key(ns['test_data'])
    ci = key(ci_rows)
    save('B_bundle', {'cells': recs, 'host_deviation': 'MAX_MEMORY_USAGE_RATIO=3.0 in E2E cell 13 (producer only)',
                      'zip_bytes': zp.stat().st_size, 'zip_sha256': sha, 'members': len(names),
                      'largest_members': sorted(names, key=lambda t: -t[1])[:5], 'target': target, 'new_rows': len(new),
                      'new_columns': list(new.columns), 'partition_rows': {'train': len(ns['train_data']), 'test': len(ns['test_data'])},
                      'ci_workflow_tail24_overlap': {'with_support_train': len(ci & support), 'with_holdout': len(ci & val),
                                                     'with_test': len(ci & test), 'ci_rows': len(ci)},
                      'ns_partition_names': [k for k in ns if k.endswith('_data')]})


def default_jupyter():
    """Default Run all, no form edited, plain Jupyter kernel (no google.colab)."""
    fresh_inf_dir()
    src = cells(NB)
    ns = {'__name__': '__main__'}
    recs = [run(ns, src, i, label='default/jupyter') for i in (3, 5, 7, 9, 11, 13, 15)]
    save('P1_default_jupyter', recs)


def default_upload_no_digest():
    """Default form values on Colab where the learner uploads the bundle in the dialog (stubbed) but leaves
    EXPECTED_ZIP_SHA256 at its default empty value."""
    fresh_inf_dir()
    stub_colab()
    zp, sha, new_csv = bundle_info()
    UPLOAD.clear(); UPLOAD[zp.name] = zp.read_bytes()
    src = cells(NB)
    ns = {'__name__': '__main__'}
    recs = [run(ns, src, i, label='default/upload-stub') for i in (3, 5, 7, 9)]
    save('P2_default_upload_no_digest', recs)


def paths():
    """External-artifact path journey: all three EXE3 fields set (artifact path, trusted digest, new-input path)."""
    work = fresh_inf_dir()
    zp, sha, new_csv = bundle_info()
    src = cells(NB)
    ns = {'__name__': '__main__'}
    p9 = {'ARTIFACT_ZIP_PATH': str(zp), 'EXPECTED_ZIP_SHA256': sha}
    recs = []
    for i in (3, 5, 7, 9, 11, 13, 15):
        recs.append(run(ns, src, i, p9 if i == 9 else ({'NEW_DATA_PATH': str(new_csv)} if i == 13 else None), label='paths'))
    import numpy as np
    import pandas as pd
    out = ns['out']
    labelled = pd.read_csv(ROOT / 'new_rows_labelled.csv')
    target = ns['TARGET_COLUMN']
    y, p = labelled[target].to_numpy(float), out['prediction'].to_numpy(float)
    mae = float(np.mean(np.abs(y - p)))
    mean_base = float(np.mean(np.abs(y - y.mean())))
    result = json.loads((work / 'outputs' / f'{OUTP}_result.json').read_text(encoding='utf-8'))
    blob = json.dumps(result).lower()
    save('P3_paths', {
        'cells': recs,
        'outputs': sorted(os.listdir(work / 'outputs')),
        'rows': len(out), 'prediction_dtype': str(out['prediction'].dtype),
        'predictions_finite': bool(np.isfinite(p).all()),
        'prediction_range': [float(p.min()), float(p.max())],
        'input_manifest_findings': ns['input_manifest']['findings'],
        'eval_verdict': ns['report']['verdict'],
        'sample_kind': ns['report']['sample_kind'],
        'reviewer_side_mae_vs_withheld_labels': mae,
        'reviewer_side_mae_of_test_mean_reference': mean_base,
        'result_digest_verified': result['artifact']['digest_verified'],
        'secret_like_strings_in_result': [k for k in ('token', 'hf_', 'password', 'secret') if k in blob],
        'pipe_snapshot_used_for_serving': str(ns['serving'].model_weight_path),
        'serving_model_weight_path_is_section3_pipe': str(ns['serving'].model_weight_path) == str(ns['pipe'].model_weight_path),
    })


def mixed():
    """Artifact by path (+digest) but NEW_DATA_PATH empty -> the cell-13 upload branch (Colab stub supplies a CSV)."""
    fresh_inf_dir()
    stub_colab()
    zp, sha, new_csv = bundle_info()
    src = cells(NB)
    ns = {'__name__': '__main__'}
    recs = [run(ns, src, i, {'ARTIFACT_ZIP_PATH': str(zp), 'EXPECTED_ZIP_SHA256': sha} if i == 9 else None, label='mixed') for i in (3, 5, 7, 9, 11)]
    UPLOAD.clear(); UPLOAD['my_rows.csv'] = new_csv.read_bytes()
    recs.append(run(ns, src, 13, label='mixed: NEW_DATA_PATH empty, upload stub has one CSV'))
    save('P4_mixed_artifact_path_csv_upload', recs)


def recovery():
    """Representative invalid inputs and their messages (one process; Section 3 staged once)."""
    fresh_inf_dir()
    zp, sha, new_csv = bundle_info()
    src = cells(NB)
    ns = {'__name__': '__main__'}
    res = {'setup': [run(ns, src, i, label='setup') for i in (3, 5, 7)]}
    res['R1_wrong_digest'] = run(ns, src, 9, {'ARTIFACT_ZIP_PATH': str(zp), 'EXPECTED_ZIP_SHA256': '0' * 64}, 'wrong digest')
    res['R2_bad_digest_format'] = run(ns, src, 9, {'ARTIFACT_ZIP_PATH': str(zp), 'EXPECTED_ZIP_SHA256': 'abc'}, 'non-hex digest')
    tam = ROOT / 'external' / 'tampered.zip'
    shutil.copy2(zp, tam)
    with zipfile.ZipFile(tam, 'a') as zf:
        zf.writestr('extra_payload.txt', 'not in manifest')
    tsha = hashlib.sha256(tam.read_bytes()).hexdigest()
    res['R3_unlisted_member'] = run(ns, src, 9, {'ARTIFACT_ZIP_PATH': str(tam), 'EXPECTED_ZIP_SHA256': tsha}, 'unlisted member')
    trav = ROOT / 'external' / 'traversal.zip'
    with zipfile.ZipFile(trav, 'w') as zf:
        zf.writestr('../evil.txt', 'x')
    res['R4_traversal'] = run(ns, src, 9, {'ARTIFACT_ZIP_PATH': str(trav), 'EXPECTED_ZIP_SHA256': hashlib.sha256(trav.read_bytes()).hexdigest()}, 'traversal')
    res['R5_override_unverified'] = run(ns, src, 9, {'ARTIFACT_ZIP_PATH': str(zp), 'ALLOW_UNVERIFIED_ARTIFACT': True}, 'override, no digest')
    res['R6_good_bundle'] = run(ns, src, 9, {'ARTIFACT_ZIP_PATH': str(zp), 'EXPECTED_ZIP_SHA256': sha}, 'good')
    res['R6_reconstruct'] = run(ns, src, 11, label='reconstruct')
    import pandas as pd
    df = pd.read_csv(new_csv)
    feats = ns['FEATURE_COLUMNS']
    bad = ROOT / 'bad_missing.csv'; df.drop(columns=[feats[0]]).to_csv(bad, index=False)
    res['R7_missing_feature'] = run(ns, src, 13, {'NEW_DATA_PATH': str(bad)}, 'missing feature')
    pre = ROOT / 'bad_prediction_col.csv'; df.assign(prediction=0.0).to_csv(pre, index=False)
    res['R8_prediction_column'] = run(ns, src, 13, {'NEW_DATA_PATH': str(pre)}, 'existing prediction column')
    txt = ROOT / 'bad_text_feature.csv'; df.assign(**{feats[0]: 'abc'}).to_csv(txt, index=False)
    res['R11_non_numeric_feature'] = run(ns, src, 13, {'NEW_DATA_PATH': str(txt)}, 'non-numeric feature values')
    res['R11_non_numeric_predict'] = run(ns, src, 15, label='non-numeric predict')
    one = ROOT / 'one_row.csv'; df.head(1).to_csv(one, index=False)
    res['R9_one_row'] = run(ns, src, 13, {'NEW_DATA_PATH': str(one)}, 'one row')
    res['R9_one_row_predict'] = run(ns, src, 15, label='one row predict')
    lab = ROOT / 'new_rows_labelled.csv'
    res['R10_labelled_rows_with_target'] = run(ns, src, 13, {'NEW_DATA_PATH': str(lab)}, 'labelled rows incl target col')
    res['R10_extra_cols'] = ns.get('extra_columns')
    res['R10_predict'] = run(ns, src, 15, label='labelled rows predict')
    res['R10_eval_verdict'] = ns['report']['verdict'] if 'report' in ns else None
    save('P5_recovery', res)


def bundle_alone():
    """Does the predictor reconstruct from the bundle alone (no Section 3 staging, empty HF cache, offline)?"""
    work = ROOT / 'alone'
    shutil.rmtree(work, ignore_errors=True); work.mkdir()
    os.environ['HF_HOME'] = str(work / 'hf-empty')
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['TRANSFORMERS_OFFLINE'] = '1'
    zp, sha, new_csv = bundle_info()
    import pandas as pd
    t0 = time.time()
    try:
        with zipfile.ZipFile(zp) as zf:
            zf.extractall(work / 'bundle')
        from autogluon.tabular import TabularPredictor
        p = TabularPredictor.load(str(work / 'bundle'))
        pred = p.predict(pd.read_csv(new_csv))
        rec = {'error': None, 'rows': len(pred), 'problem_type': p.problem_type}
    except BaseException as exc:  # noqa: BLE001
        rec = {'error': f'{type(exc).__name__}: {str(exc)[:600]}'}
    rec['seconds'] = round(time.time() - t0, 1)
    rec['hf_cache_files_after'] = [str(q.relative_to(work)) for q in (work / 'hf-empty').rglob('*') if q.is_file()] if (work / 'hf-empty').exists() else []
    save('P6_bundle_alone_offline_empty_cache', rec)


def static():
    nb = json.loads(NB.read_text(encoding='utf-8'))
    src = [''.join(c['source']) for c in nb['cells']]
    md = '\n'.join(s for s, c in zip(src, nb['cells']) if c['cell_type'] == 'markdown')
    code = [(i, s) for i, (s, c) in enumerate(zip(src, nb['cells'])) if c['cell_type'] == 'code']
    comp = {}
    for i, s in code:
        try:
            compile(s, f'cell{i}', 'exec'); comp[i] = 'ok'
        except SyntaxError as exc:
            comp[i] = f'SyntaxError: {exc}'
    gen = subprocess.run([sys.executable, 'tools/build_notebook.py', '--template', 'tools/notebook_template_artifact_inference.py', '--check'],
                         cwd=REPO, capture_output=True, text=True)
    gf = nb['metadata']['dimer']['generated_from']
    def blob_sha(rev):
        r = subprocess.run(['git', 'show', f'{rev}:mitra_pipeline/tutorial_api.py'], cwd=REPO, capture_output=True)
        return hashlib.sha256(r.stdout).hexdigest() if r.returncode == 0 else None
    last_module_commit = subprocess.run(['git', 'log', '-1', '--format=%H', '--', 'mitra_pipeline/tutorial_api.py'], cwd=REPO, capture_output=True, text=True).stdout.strip()
    lc = md.lower()
    save('S_static', {
        'nbformat': f"{nb['nbformat']}.{nb['nbformat_minor']}",
        'metadata_dimer': nb['metadata'].get('dimer'),
        'cells': len(nb['cells']), 'code_cells': [i for i, _ in code],
        'outputs_persisted': sum(len(c.get('outputs', [])) for c in nb['cells']),
        'compile': comp,
        'generator_check': {'rc': gen.returncode, 'out': (gen.stdout + gen.stderr)[-600:]},
        'files_import_cells': [i for i, s in code if re.search(r'from google\.colab import files', s)],
        'files_upload_cells': [i for i, s in code if re.search(r'\bfiles\.upload\(', s)],
        'module_cell_chars': len(src[5]), 'module_cell_lines': src[5].count('\n') + 1,
        'markers': {k: (k in lc) for k in ('expected result', 'what to notice', 'checkpoint', 'predict', 'glossary', 'troubleshoot',
                                            'how to use', 'infrastructure', 'input →', 'conclusion', 'exercise', 'try this')},
        'spec_declared': nb['metadata']['dimer'].get('notebook_spec'),
        'pipe_not_used_claim_in_md': 'is not used for inference' in md,
        'pipe_used_in_cell11': 'pipe.model_weight_path' in src[11],
        'evaluation_report_sample_kind_literal': re.findall(r"sample_kind='(\w+)'", src[15]),
        'ceilings_printed': re.findall(r"'(M\w+_\w+)'", src[13]),
        'provenance': {'declared_revision': gf['revision'], 'declared_module_sha256': gf['module_sha256'],
                       'module_sha256_at_declared_revision': blob_sha(gf['revision']),
                       'module_sha256_at_HEAD': blob_sha('HEAD'), 'last_commit_touching_module': last_module_commit,
                       'module_sha256_at_last_module_commit': blob_sha(last_module_commit)},
    })


if __name__ == '__main__':
    globals()[MODE]()
