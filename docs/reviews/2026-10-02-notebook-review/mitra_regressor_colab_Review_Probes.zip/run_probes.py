"""Review probes for tutorials/mitra_regressor_colab.ipynb (row 49, prefix MRC).

Direct CPU execution of the notebook's own code cells, in order, in one namespace, with the install cell
skipped (DIMER_NOTEBOOK_CI_PREINSTALLED=1) inside the repository's read-only .venv, which holds the notebook's
exact pins (autogluon.tabular 1.5.0, lightgbm 4.6.0, huggingface-hub 0.36.2; torch 2.9.1 CPU; scikit-learn 1.7.2,
where the Kaggle record had 1.6.1). The digest-verified Mitra snapshot is pre-copied into each work directory, so
stage_missing_files fetches nothing (the Hub download is NOT exercised here). google.colab.files.upload is stubbed
with in-memory payloads for the BYOD probes. Form values are changed only by rewriting the cell's own
`NAME = value  # @param` assignment line. No memory override is applied unless MRC_MEMORY_RATIO is set.

Usage: python run_probes.py NOTEBOOK WORKDIR RESULTS {static|default_and_active|finetune_selection|byod}
"""
from __future__ import annotations

import contextlib
import io
import json
import os
import re
import sys
import time
import types
import warnings
import zipfile
from pathlib import Path

NB, WORK, RESULTS, MODE = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), sys.argv[4]
REPO = NB.parent.parent
_NB = json.loads(NB.read_text(encoding='utf-8'))
CELLS = [''.join(c['source']) for c in _NB['cells']]
CODE = [i for i, c in enumerate(_NB['cells']) if c['cell_type'] == 'code']
UPLOAD: dict[str, bytes] = {}
MEM = os.environ.get('MRC_MEMORY_RATIO')


def save(key, value):
    data = json.loads(RESULTS.read_text(encoding='utf-8')) if RESULTS.exists() else {}
    data[key] = value
    RESULTS.write_text(json.dumps(data, indent=2, default=str), encoding='utf-8')


def set_param(src: str, name: str, value) -> str:
    pat = re.compile(rf'^{name} = .*?(  # @param.*)?$', re.M)
    assert pat.search(src), name
    return pat.sub(lambda m: f'{name} = {value!r}' + (m.group(1) or ''), src, count=1)


def run(ns, idx, params=None, label=None):
    src = CELLS[idx]
    params = dict(params or {})
    if idx == 13 and MEM:
        params.setdefault('MAX_MEMORY_USAGE_RATIO', float(MEM))
    for k, v in params.items():
        src = set_param(src, k, v)
    out = io.StringIO()
    t0 = time.time()
    err = None
    with warnings.catch_warnings(record=True) as caught, contextlib.redirect_stdout(out), contextlib.redirect_stderr(out):
        warnings.simplefilter('always')
        try:
            exec(compile(src, f'cell{idx}', 'exec'), ns)
        except BaseException as exc:  # noqa: BLE001
            err = f'{type(exc).__name__}: {exc}'
    text = out.getvalue()
    rec = {'cell': idx, 'label': label, 'params': dict(params), 'seconds': round(time.time() - t0, 1),
           'error': err, 'stdout_lines': text.count('\n'), 'stdout_tail': text[-2500:],
           'autogluon_split_line': next((l.strip() for l in text.splitlines() if 'holdout_frac' in l), None),
           'warnings': sorted({f'{w.category.__name__}: {str(w.message)[:160]}' for w in caught})}
    print(f'cell {idx} {label or ""} {rec["seconds"]}s err={err}', file=sys.__stdout__, flush=True)
    return rec


def setup():
    os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
    os.chdir(WORK)
    colab = types.ModuleType('google.colab')
    colab.files = types.SimpleNamespace(upload=lambda: dict(UPLOAD))
    google = types.ModuleType('google')
    google.colab = colab
    sys.modules['google'] = google
    sys.modules['google.colab'] = colab
    ns = {'__name__': '__main__'}
    recs = [run(ns, i) for i in (3, 5, 7)]
    return ns, recs


def mitra_context(ns):
    p = ns['ACTIVE_MODEL'].predictor
    m = p._trainer.load_model(p.model_best)
    inner = getattr(m, 'model', None)
    ctx = int(len(inner.X)) if inner is not None and hasattr(inner, 'X') else None
    try:
        val = int(len(p.load_data_internal('val')[0]))
    except Exception as exc:  # noqa: BLE001
        val = f'unavailable: {exc}'
    return ctx, val


def default_and_active():
    ns, recs = setup()
    for i in CODE[3:]:
        recs.append(run(ns, i, label='default'))
    ctx, val = mitra_context(ns)
    meta = json.loads((Path(ns['active_path']) / 'tutorial_run_metadata.json').read_text(encoding='utf-8'))
    save('P1_default', {
        'cells': recs,
        'support_rows_after_validation': len(ns['train_data']),
        'mitra_in_context_rows': ctx, 'autogluon_val_rows': val,
        'run_metadata_train_rows_used': meta['train_rows_used'],
        'lightgbm_rf_fit_rows': len(ns['X_train_tree']),
        'metrics_table': ns['metrics_table'].round(4).to_dict(orient='records'),
        'holdout_rows': len(ns['holdout_data']), 'test_rows': len(ns['test_data']),
        'outputs': sorted(os.listdir('outputs')),
        'device': ns['ACTIVE_MODEL'].device,
        'predictions_head': ns['out']['prediction'].tolist(),
    })
    # Active learning: change the documented EVAL_METRIC control and rerun Section 6 onward.
    act = [run(ns, 13, {'EVAL_METRIC': 'root_mean_squared_error'}, label='active: EVAL_METRIC=rmse')]
    for i in (15, 17, 19):
        act.append(run(ns, i, label='active rerun'))
    rep = json.loads(Path('outputs/mitra_regressor_evaluation_report.json').read_text(encoding='utf-8'))
    meta2 = json.loads((Path(ns['active_path']) / 'tutorial_run_metadata.json').read_text(encoding='utf-8'))
    save('P3_active_eval_metric', {
        'cells': act,
        'autogluon_eval_metric': str(ns['pipe'].predictor.eval_metric),
        'report_selection': rep.get('selection'), 'run_metadata_eval_metric': meta2.get('eval_metric'),
        'metrics_table': ns['metrics_table'].round(4).to_dict(orient='records'),
    })


def finetune_selection():
    """Cell 13 with RUN_FINE_TUNING=True, GPU check stubbed True, and the candidate's fit replaced by a stand-in
    that reuses the registered pretrained predictor and shifts its predictions by +5 target units (so the candidate
    is worse on the holdout), then with no shift. Everything after candidate.fit is cell 13's own code. Then the
    real CPU gate."""
    ns, recs = setup()
    for i in (9, 11):
        recs.append(run(ns, i))
    import numpy as np
    import torch
    real_avail, real_cls = torch.cuda.is_available, ns['MitraRegressionPipeline']
    holder = {'shift': 5.0}

    class StandIn(real_cls):
        def fit(self, *a, **kw):
            self.predictor = holder['pipe'].predictor
            self.features = list(holder['pipe'].features)
            return self

        def predict(self, frame):
            return np.asarray(super().predict(frame), dtype=float) + holder['shift']

    orig_fit = real_cls.fit

    def pipe_fit(self, *a, **kw):
        holder['pipe'] = self
        return orig_fit(self, *a, **kw)

    real_cls.fit = pipe_fit
    torch.cuda.is_available = lambda: True
    ns['MitraRegressionPipeline'] = StandIn
    try:
        sel = run(ns, 13, {'RUN_FINE_TUNING': True}, label='fine-tune selection, stand-in candidate (+5 shift)')
        sel_basis = (ns.get('SELECTION_BASIS'), ns.get('ACTIVE_MODE'))
        holder['shift'] = -0.0
        sel0 = run(ns, 13, {'RUN_FINE_TUNING': True}, label='fine-tune selection, stand-in candidate (no shift)')
        sel0_basis = (ns.get('SELECTION_BASIS'), ns.get('ACTIVE_MODE'))
    finally:
        torch.cuda.is_available = real_avail
        ns['MitraRegressionPipeline'] = real_cls
        real_cls.fit = orig_fit
    save('P2_finetune_selection_standin', {'setup': recs, 'cell13_shift5': sel, 'basis_mode_shift5': sel_basis,
                                           'cell13_noshift': sel0, 'basis_mode_noshift': sel0_basis})
    gate = run(ns, 13, {'RUN_FINE_TUNING': True}, label='fine-tune gate on CPU (real)')
    save('P2b_finetune_gate_cpu', gate)


def zip_members(name):
    with zipfile.ZipFile(REPO / 'examples' / 'sample-data' / name) as zf:
        return {m: zf.read(m) for m in zf.namelist()}


def byod():
    import pandas as pd
    ns, recs = setup()
    res = {'setup': recs}
    ins = zip_members('insurance-medical-charges.zip')
    ames = zip_members('ames-housing.zip')
    up = {'USE_BYOD': True}
    pre = {**up, 'DATA_SOURCE': 'Upload pre-split train/val/test'}
    # R1: pre-split Insurance CSVs with the default TARGET_COLUMN='target' (Next experiments does not mention it).
    UPLOAD.clear(); UPLOAD.update(ins)
    res['R1_presplit_default_target'] = [run(ns, 9, pre, label='insurance default target'), run(ns, 11, label='insurance default target')]
    # R2: the archive itself uploaded (the text says "archives").
    UPLOAD.clear(); UPLOAD['insurance-medical-charges.zip'] = (REPO / 'examples/sample-data/insurance-medical-charges.zip').read_bytes()
    res['R2_zip_upload'] = run(ns, 9, pre, label='zip upload')
    # R3: Upload CSV without USE_BYOD.
    res['R3_upload_without_use_byod'] = run(ns, 9, {'DATA_SOURCE': 'Upload CSV'}, label='no USE_BYOD')
    # R4: invalid single CSV: non-numeric target.
    bad = pd.DataFrame({'x': range(120), 'y': ['high' if i % 2 else 'low' for i in range(120)]})
    UPLOAD.clear(); UPLOAD['text_target.csv'] = bad.to_csv(index=False).encode()
    res['R4_non_numeric_target'] = [run(ns, 9, {**up, 'DATA_SOURCE': 'Upload CSV', 'TARGET_COLUMN': 'y'}), run(ns, 11)]
    # R4b: VALIDATION_SPLIT out of range is checked only after the upload dialog.
    UPLOAD.clear(); UPLOAD['ames_train.csv'] = ames['train.csv']
    res['R4b_validation_split_out_of_range'] = run(ns, 9, {**up, 'DATA_SOURCE': 'Upload CSV', 'TARGET_COLUMN': 'SalePrice', 'VALIDATION_SPLIT': 0.5})
    # R5: valid pre-split Insurance with TARGET_COLUMN='charges' through every stage.
    UPLOAD.clear(); UPLOAD.update(ins)
    r5 = [run(ns, 9, {**pre, 'TARGET_COLUMN': 'charges'}, label='insurance')]
    for i in CODE[4:]:
        r5.append(run(ns, i, label='insurance'))
    ctx, val = mitra_context(ns)
    res['R5_presplit_insurance_full'] = {'cells': r5, 'mitra_in_context_rows': ctx, 'autogluon_val_rows': val,
                                         'support_rows': len(ns['train_data']),
                                         'metrics_table': ns['metrics_table'].round(4).to_dict(orient='records') if 'metrics_table' in ns else None,
                                         'overlaps': ns.get('overlaps')}
    # R6: new-data inference via NEW_DATA_PATH: valid rows (test features without target), then a CSV missing a feature.
    test = pd.read_csv(io.BytesIO(ins['test.csv']))
    good = test.drop(columns=['charges']).head(20)
    good.to_csv('new_rows.csv', index=False)
    res['R6_new_data_valid'] = run(ns, 17, {'RUN_NEW_DATA_INFERENCE': True, 'NEW_DATA_PATH': 'new_rows.csv'})
    good.drop(columns=[ns['FEATURE_COLUMNS'][0]]).to_csv('new_rows_missing.csv', index=False)
    res['R6b_new_data_missing_feature'] = run(ns, 17, {'RUN_NEW_DATA_INFERENCE': True, 'NEW_DATA_PATH': 'new_rows_missing.csv'})
    # R7: single-CSV upload path (Upload CSV): Ames train.csv only, TARGET_COLUMN='SalePrice', through export.
    UPLOAD.clear(); UPLOAD['ames_train.csv'] = ames['train.csv']
    r7 = [run(ns, 9, {**up, 'DATA_SOURCE': 'Upload CSV', 'TARGET_COLUMN': 'SalePrice'}, label='ames single csv')]
    for i in (11, 13, 15, 17, 19):
        r7.append(run(ns, i, label='ames single csv'))
    res['R7_single_csv_ames'] = {'cells': r7, 'test_data_is_none': ns.get('test_data') is None,
                                 'metrics_table': ns['metrics_table'].round(4).to_dict(orient='records') if 'metrics_table' in ns else None}
    save('P4_byod', res)


def static():
    nb = _NB
    allsrc = '\n'.join(CELLS)
    md = '\n'.join(''.join(c['source']) for c in nb['cells'] if c['cell_type'] == 'markdown')
    pre_upload_md = '\n'.join(''.join(c['source']) for c in nb['cells'][:9] if c['cell_type'] == 'markdown')
    save('S_static', {
        'cells': len(nb['cells']), 'code_cells': CODE,
        'declared_spec': nb['metadata']['dimer']['notebook_spec'], 'mode': nb['metadata']['dimer']['notebook_mode'],
        'cell_chars': {i: len(s) for i, s in enumerate(CELLS)},
        'collapsed_or_hidden_code_cells': [i for i, c in enumerate(nb['cells']) if c['cell_type'] == 'code' and (c.get('metadata', {}).get('cellView') == 'form' or c.get('metadata', {}).get('jupyter', {}).get('source_hidden'))],
        'guided_markers_case_insensitive': {k: (k.lower() in md.lower()) for k in ('How to use', 'Expected result', 'What to notice', 'Check your reasoning', 'Glossary', 'Troubleshooting', 'Infrastructure', 'Input →', 'Roadmap', 'conclusion template', 'Predict →')},
        'reviewer_facing_open_decision_sentence': 'should treat that as an open decision' in md,
        'eval15_cited_for_same_rows': 'same partitions (EVAL15)' in md,
        'same_support_rows_claim': 'exact same support rows' in md,
        'tuning_data_or_holdout_frac_in_carrier': ('tuning_data' in CELLS[5]) or ('holdout_frac' in CELLS[5]),
        'refit_full_anywhere': 'refit_full' in allsrc,
        'pre_upload_markdown_states': {k: (k in pre_upload_md) for k in ('MIN_TRAIN_ROWS', 'MAX_TRAIN_ROWS', 'MAX_FEATURES', '10,000', '500', 'numeric', 'SalePrice', 'charges')},
        'restart_guard_present': 'Restart the runtime, then rerun from the top' in allsrc,
        'uv_used': 'uv venv' in allsrc,
        'sample_configs_in_notebook': 'SAMPLE_CONFIGS' in allsrc, 'sample_revision_in_notebook': 'SAMPLE_REVISION' in allsrc,
    })


{'static': static, 'default_and_active': default_and_active, 'finetune_selection': finetune_selection, 'byod': byod}[MODE]()
